﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MortgageCalculator.Api;
using System.Web.Mvc;

namespace MortgageCalculator.UnitTests
{
    [TestFixture]
    public class MortgageTest
    {
        [Test]
        public void TestGet()
        {
            MortgageCalculator.Api.Controllers.MortgageController TEST = new Api.Controllers.MortgageController();
            var result = TEST.Get();
            Assert.IsNotNull(result);
        }

        [Test]
        public void TestGetMortgageType()
        {
            MortgageCalculator.Api.Controllers.MortgageController TEST = new Api.Controllers.MortgageController();
            var result = TEST.GetMortgageType();
            Assert.IsNotNull(result);
            
        }
        [Test]
        public void TestMethod()
        {
            MortgageCalculator.Web.Controllers.HomeController TEST = new Web.Controllers.HomeController();
            ActionResult result = TEST.Index();
            Assert.AreEqual(result, typeof(ActionResult));
            
        }
    }
}
