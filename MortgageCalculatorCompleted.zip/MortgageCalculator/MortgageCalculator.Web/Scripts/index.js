﻿$(document).ready(function () {
    $.ajax({
        type: "GET",
        contentType: "application/json; charset=utf-8",
        url: "http://localhost:52187/Home/getMortgageType",
        dataType: "json",
        success: function (Result) {
            //debugger;
            $.each(Result, function (key, value) {
                $("#ddlMortgageType").append($("<option></option>").html(value));
            });
        },
        error: function (Result) {
            alert("Error");
        }
    });


});
function CalculatePayment() {
    debugger;
    var error = 0;
    var EnteredAmount = $('#IpBorrowedAmt').val();
    var MortgageType = $('#ddlMortgageType').val();
    var Interest = $('#IpInterest').val();
    var Duration = $('#Ipterms').val();
    if (EnteredAmount == '') {
        error = 1;
        $('#amount_error_msg').html("Amount cannot be empty");
        $('#amount_error_msg').parent().show();
    }
    if (Duration == '') {
        error = 1;
        $('#Duration_error_msg').html("Duration cannot be empty");
        $('#Duration_error_msg').parent().show();
    }
    if (Interest == '') {
        error = 1;
        $('#Interest_error_msg').html("Interest cannot be empty");
        $('#Interest_error_msg').parent().show();
    }   
    if (error) {
        return false;
    }
    else {
        $('#amount_error_msg').hide();
        $('#Duration_error_msg').hide();
        $('#Interest_error_msg').hide();
    }
    var M; //monthly mortgage payment
    var P = EnteredAmount; //principle / initial amount borrowed
    var I = Interest / 100 / 12; //monthly interest rate
    var N = $('#Ipterms').val() * 12; //number of payments months
    var MonthlyEMI = Math.round((P * I) / (1 - Math.pow(1 + I, -N)));
    var TotalRepayment = Math.round(MonthlyEMI * N);
    var totalInterest = Math.round(TotalRepayment - EnteredAmount);
    document.getElementById('TotalRepaymentLabel').innerHTML = TotalRepayment;
    //document.getElementById('InterestLabel').innerHTML = Interest;
    document.getElementById('MontlhyEMIlbl').innerHTML = MonthlyEMI;
    document.getElementById('TotalInterestlbl').innerHTML = totalInterest;
    //$('#TotalRepaymentLabel').val(TotalRepayment);
    //$('#InterestLabel').val(Interest);
    //$('#MontlhyEMIlbl').val(MonthlyEMI);
    //alert(m);
    //debugger;
}


