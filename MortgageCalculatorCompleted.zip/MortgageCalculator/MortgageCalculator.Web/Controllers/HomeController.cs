﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace MortgageCalculator.Web.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            IEnumerable<MortgageCalculator.Dto.Mortgage> Mortgage = null;

            using (var client = new HttpClient())
            {

                client.BaseAddress = new Uri("http://localhost:49608/api/Mortgage/");
                //HTTP GET
                var responseTask = client.GetAsync("Get");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<MortgageCalculator.Dto.Mortgage>>();
                    readTask.Wait();

                    Mortgage = readTask.Result.OrderBy(e => e.MortgageType).OrderBy(x => x.EstablishmentFee);

                }
                else //web api sent error response 
                {


                    Mortgage = Enumerable.Empty<MortgageCalculator.Dto.Mortgage>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View(Mortgage);
        }

        public JsonResult getMortgageType()
        {
            List<string> MortgageType = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:49608/api/Mortgage/");
                //HTTP GET
                var responseTask = client.GetAsync("GetMortgageType");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IList<string>>();
                    readTask.Wait();

                    MortgageType = readTask.Result.ToList();

                }
                else //web api sent error response 
                {


                    MortgageType = new List<string>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }

            }
            var MortgageTypes = JsonConvert.SerializeObject(MortgageType);
            return Json(MortgageType, JsonRequestBehavior.AllowGet);
        }
    }
}