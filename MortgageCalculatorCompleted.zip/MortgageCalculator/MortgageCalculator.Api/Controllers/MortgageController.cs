﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using MortgageCalculator.Api.Services;

namespace MortgageCalculator.Api.Controllers
{
    // GET: api/Mortgage
    [RoutePrefix("api/Mortgage")]
    public class MortgageController : ApiController
    {
        
        [Route("Get")]
        public IEnumerable<Dto.Mortgage> Get()
        {
           var mortgageService = new MortgageService();
            return mortgageService.GetAllMortgages();
        }

        // GET: api/Mortgage/5
        [Route("Get/{id}")]
        public Dto.Mortgage Get(int id)
        {
            var mortgageService = new MortgageService();
            return mortgageService.GetAllMortgages().FirstOrDefault(x => x.MortgageId == id);
        }

        [Route("GetMortgageType")]
        public List<string> GetMortgageType()
        {
            var mortgageService = new MortgageService();
            return mortgageService.GetMortgageType();
        }
    }
}
